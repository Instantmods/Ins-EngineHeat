Config = {}

Config.SpeedLimit = 100.0 
Config.MaxTemperature = 100.0 
Config.CooldownRate = 1.0 
Config.HeatUpRate = 0.5 
Config.WearDownRate = 1.0 
Config.MaxEngineHealth = 150.0
Config.Unit = 'kmh' -- mph or kmh
Config.Notification = 'mythic_notify'


