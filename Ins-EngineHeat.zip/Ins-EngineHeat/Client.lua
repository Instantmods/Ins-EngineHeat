Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1000) 

        local playerPed = PlayerPedId()
        if IsPedInAnyVehicle(playerPed, false) then
            local vehicle = GetVehiclePedIsIn(playerPed, false)
            local speed = GetEntitySpeed(vehicle)
            local speedConverted = convertSpeed(speed, Config.Unit)

            if speedConverted > Config.SpeedLimit then
                engineTemperature = engineTemperature + Config.HeatUpRate
                if engineTemperature > Config.MaxTemperature then
                    engineHealth = engineHealth - Config.WearDownRate
                    SetVehicleEngineHealth(vehicle, engineHealth)
                    notifyPlayer("Engine overheating!", "error")
                    if engineHealth <= 0.0 then
                        SetVehicleEngineOn(vehicle, false, true, true)
                        notifyPlayer("Engine stopped due to overheating!", "error")
                    end
                end
            else
                engineTemperature = engineTemperature - Config.CooldownRate
                if engineTemperature < 0 then
                    engineTemperature = 0
                end
                if engineHealth < Config.MaxEngineHealth then
                    engineHealth = engineHealth + Config.RepairRate
                    SetVehicleEngineHealth(vehicle, engineHealth)
                end
            end

            if engineHealth < 0 then
                engineHealth = 0
            end
        else
            engineTemperature = 0.0
        end
    end
end)
