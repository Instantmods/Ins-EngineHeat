fx_version 'cerulean'
games { 'gta5' }

author 'Instant Modifications'
description 'Standalone Engine Heat Script'
version '1.0.0'

client_script 'Config.lua'
client_script 'Client.lua'
